export default {
  base: "/joke-app/",
};
